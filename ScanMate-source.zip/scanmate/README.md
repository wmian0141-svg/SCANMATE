# ScanMate (Flutter source)

A starter Android/iOS Flutter app with a blue-and-white interface. Current features:
- Capture one page using the camera
- Import an image from the gallery
- Add/remove pages in the current scan
- Create an A4 PDF saved in the app's documents folder
- Share the generated PDF using the system share sheet

## Build an Android APK for free

You need Flutter installed locally, or use a free GitHub account and GitHub Actions.

### Local build
1. Install Flutter SDK and Android Studio / Android SDK.
2. In this folder, run `flutter pub get`.
3. Run `flutter create .` once to generate the Android platform folder if it is missing.
4. Run `flutter build apk --release`.
5. APK output: `build/app/outputs/flutter-apk/app-release.apk`.

### Notes
- This is a starter version, not yet a full CamScanner replacement.
- PDF output currently places each selected image on an A4 page; automatic edge detection, perspective correction, OCR, and cloud sync are not included yet.
- Test on your own device before publishing. Google Play registration and publishing have separate requirements/fees.
