import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

void main() => runApp(const ScanMateApp());

class ScanMateApp extends StatelessWidget {
  const ScanMateApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF102A43);
    const blue = Color(0xFF2878F0);
    return MaterialApp(
      title: 'ScanMate',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        scaffoldBackgroundColor: const Color(0xFFF5F8FC),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F8FC), foregroundColor: navy),
      ),
      home: const ScannerHome(),
    );
  }
}

class ScannerHome extends StatefulWidget {
  const ScannerHome({super.key});
  @override
  State<ScannerHome> createState() => _ScannerHomeState();
}

class _ScannerHomeState extends State<ScannerHome> {
  final ImagePicker _picker = ImagePicker();
  final List<XFile> _pages = [];
  bool _working = false;
  String? _lastPdf;

  Future<void> _addImage(ImageSource source) async {
    try {
      final image = await _picker.pickImage(source: source, imageQuality: 92);
      if (image != null && mounted) {
        setState(() {
          _pages.add(image);
          _lastPdf = null;
        });
        _message('Page added to your scan.');
      }
    } catch (e) {
      _message('Could not open image picker. Please try again.');
    }
  }

  Future<void> _makePdf() async {
    if (_pages.isEmpty) {
      _message('Add a page with Camera or Gallery first.');
      return;
    }
    setState(() => _working = true);
    try {
      final document = pw.Document();
      for (final page in _pages) {
        final bytes = await File(page.path).readAsBytes();
        final image = pw.MemoryImage(bytes);
        document.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(18),
          build: (_) => pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain)),
        ));
      }
      final directory = await getApplicationDocumentsDirectory();
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final file = File('${directory.path}/ScanMate_$stamp.pdf');
      await file.writeAsBytes(await document.save());
      if (!mounted) return;
      setState(() => _lastPdf = file.path);
      _message('PDF saved inside ScanMate. Tap Share PDF to send it.');
    } catch (e) {
      _message('PDF creation failed. Please try again.');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _sharePdf() async {
    final path = _lastPdf;
    if (path == null) {
      _message('Create a PDF first.');
      return;
    }
    await Share.shareXFiles([XFile(path)], text: 'Scanned with ScanMate');
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF2878F0);
    const navy = Color(0xFF102A43);
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.document_scanner_rounded, color: blue, size: 29),
          SizedBox(width: 9),
          Text('ScanMate', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -0.5)),
        ]),
      ),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 28), children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF2878F0), Color(0xFF1555C0)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(26),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.auto_awesome, color: Colors.white, size: 28),
              SizedBox(height: 18),
              Text('Your documents,\ndigitally ready.', style: TextStyle(color: Colors.white, fontSize: 27, height: 1.15, fontWeight: FontWeight.w800)),
              SizedBox(height: 10),
              Text('Scan papers or import photos and turn them into a PDF.', style: TextStyle(color: Colors.white, fontSize: 14, height: 1.4)),
            ]),
          ),
          const SizedBox(height: 24),
          const Text('Create a scan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: navy)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _ActionTile(icon: Icons.camera_alt_rounded, title: 'Camera', subtitle: 'Capture a page', onTap: () => _addImage(ImageSource.camera))),
            const SizedBox(width: 12),
            Expanded(child: _ActionTile(icon: Icons.photo_library_rounded, title: 'Gallery', subtitle: 'Choose a photo', onTap: () => _addImage(ImageSource.gallery))),
          ]),
          const SizedBox(height: 24),
          Row(children: [
            const Expanded(child: Text('Pages in this scan', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: navy))),
            Text('${_pages.length} page${_pages.length == 1 ? '' : 's'}', style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w600)),
          ]),
          const SizedBox(height: 12),
          if (_pages.isEmpty)
            Container(
              padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFDCE5F0))),
              child: const Column(children: [
                Icon(Icons.insert_drive_file_outlined, size: 42, color: Color(0xFF8AA0B8)),
                SizedBox(height: 10),
                Text('No pages yet', style: TextStyle(fontWeight: FontWeight.w700, color: navy)),
                SizedBox(height: 4),
                Text('Use Camera or Gallery to add your first page.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
              ]),
            )
          else
            ...List.generate(_pages.length, (index) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Row(children: [
                ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(_pages[index].path), width: 62, height: 76, fit: BoxFit.cover)),
                const SizedBox(width: 12),
                Expanded(child: Text('Page ${index + 1}', style: const TextStyle(fontWeight: FontWeight.w700))),
                IconButton(tooltip: 'Remove page', onPressed: () => setState(() { _pages.removeAt(index); _lastPdf = null; }), icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent)),
              ]),
            )),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _working ? null : _makePdf,
            style: FilledButton.styleFrom(backgroundColor: blue, minimumSize: const Size.fromHeight(54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            icon: _working ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.picture_as_pdf_rounded),
            label: Text(_working ? 'Creating PDF...' : 'Create PDF', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _sharePdf,
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            icon: const Icon(Icons.share_rounded),
            label: const Text('Share PDF'),
          ),
          const SizedBox(height: 18),
          const Text('ScanMate • Your documents, made simple', textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontSize: 12)),
        ]),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(20),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE1EAF4))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(color: const Color(0xFFEAF2FF), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: const Color(0xFF2878F0), size: 25)),
          const SizedBox(height: 14),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        ]),
      ),
    ),
  );
}
